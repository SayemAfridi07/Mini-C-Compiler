#include "symbol_info.h"

class scope_table
{
private:
    int bucket_count;
    int unique_id;
    scope_table *parent_scope = NULL;
    vector<list<symbol_info *>> table;

    int hash_function(string name)
    {
        // create hash function
        long long sum = 0;
        for (int i = 0; i < name.length(); i++) {
            sum += name[i];
        }
        
        return sum % bucket_count; 
    }

public:
    scope_table();
    scope_table(int bucket_count, int unique_id, scope_table *parent_scope);
    scope_table *get_parent_scope();
    int get_unique_id();
    symbol_info *lookup_in_scope(symbol_info* symbol);
    bool insert_in_scope(symbol_info* symbol);
    bool delete_from_scope(symbol_info* symbol);
    void print_scope_table(ofstream& outlog);
    ~scope_table();
};

// Default constructor
scope_table::scope_table() {
    this->bucket_count = 0;
    this->unique_id = 0;
    this->parent_scope = NULL;
}


scope_table::scope_table(int bucket_count, int unique_id, scope_table *parent_scope)
{
    this->bucket_count = bucket_count;
    this->unique_id = unique_id;
    this->parent_scope = parent_scope;
    
    
    table.resize(bucket_count);// Allocate n buckets
}

scope_table* scope_table::get_parent_scope()
{
    return parent_scope;
}


int scope_table::get_unique_id()
{
    return unique_id;
}

// lookup,correct bucket index
symbol_info* scope_table::lookup_in_scope(symbol_info* symbol)
{
    int index = hash_function(symbol->get_name());
    
    for (auto s : table[index]) {
        if (s->get_name() == symbol->get_name()) {
            return s; 
        }
    }
    return NULL; 
}

// Insert into symbol 
bool scope_table::insert_in_scope(symbol_info* symbol)
{
    
    if (lookup_in_scope(symbol) != NULL) {
        return false; // Already exists in this scope
    }
    
    int index = hash_function(symbol->get_name());
    table[index].push_back(symbol);
    return true;
}

// Delete symbol
bool scope_table::delete_from_scope(symbol_info* symbol)
{
    int index = hash_function(symbol->get_name());
    
    for (auto it = table[index].begin(); it != table[index].end(); ++it) {
        if ((*it)->get_name() == symbol->get_name()) {
            delete *it;             
            table[index].erase(it); // Remove from the linked list
            
            return true;
        }
    }
    
    return false;
}

//Print the scope table 
void scope_table::print_scope_table(ofstream& outlog)
{
    outlog << "ScopeTable # " << unique_id << endl;
    for (int i = 0; i < bucket_count; i++) {
        if (!table[i].empty()) {
            outlog << i << " --> " << endl;
            for (auto s : table[i]) {
                outlog << "< " << s->get_name() << " : " << s->get_type() << " >" << endl;
                
                if (s->get_symbol_category() == "FUNCTION") {
                    outlog << "Function Definition" << endl;
                    outlog << "Return Type: " << s->get_data_type() << endl;
                    outlog << "Number of Parameters: " << s->get_parameter_list().size() << endl;
                    outlog << "Parameter Details: ";
                    vector<string> params = s->get_parameter_list();
                    for (size_t j = 0; j < params.size(); j++) {
                        outlog << params[j];
                        if (j < params.size() - 1) outlog << ", ";
                    }
                    outlog << endl;
                }
                else if (s->get_symbol_category() == "ARRAY") {
                    outlog << "Array" << endl;
                    outlog << "Type: " << s->get_data_type() << endl;
                    outlog << "Size: " << s->get_array_size() << endl;
                }
                else {
                    outlog << "Variable" << endl;
                    outlog << "Type: " << s->get_data_type() << endl;
                }
                outlog << endl;
            }
        }
    }
}


scope_table::~scope_table()
{
    for (int i = 0; i < bucket_count; i++) {
        for (auto s : table[i]) {
            delete s; //Delete the symbol_info pointers
        }
        table[i].clear();
    }
    table.clear();
}