#include<bits/stdc++.h>
using namespace std;

class symbol_info
{
private:
    string name;
    string type;
    
    // type
    string symbol_category; //VAR,ARRAY,FUNCTION 
    
    //data type
    string data_type; //int, float, void 
    
    // Write necessary attributes to store the parameters of a function
    vector<string> parameter_list; 
    
    // Write necessary attributes to store the array size if the symbol is an array
    int array_size; 

public:
    symbol_info(string name, string type)
    {
        this->name = name;
        this->type = type;
        this->array_size = 0; 
    }

    string get_name()
    {
        return name;
    }

    string get_type()
    {
        return type;
    }

    void set_name(string name)
    {
        this->name = name;
    }

    void set_type(string type)
    {
        this->type = type;
    }

    // Write necessary functions to set and get the attributes
    
    
    void set_symbol_category(string category) {
        this->symbol_category = category;
    }
    string get_symbol_category() {
        return symbol_category;
    }

    
    void set_data_type(string d_type) {
        this->data_type = d_type;
    }
    string get_data_type() {
        return data_type;
    }

    
    void set_array_size(int size) {
        this->array_size = size;
    }
    int get_array_size() {
        return array_size;
    }

    
    void add_parameter_type(string p_type) {
        this->parameter_list.push_back(p_type);
    }
    vector<string> get_parameter_list() {
        return parameter_list;
    }

    ~symbol_info()
    {
        // Write necessary code to deallocate memory, if necessary
        
    }
};