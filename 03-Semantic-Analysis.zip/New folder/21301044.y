%{

#include "symbol_table.h"

#define YYSTYPE symbol_info*

extern FILE *yyin;
int yyparse(void);
int yylex(void);
extern YYSTYPE yylval;

// create your symbol table here.

symbol_table *st;
int lines = 1;

ofstream outlog;

// Variables to store necessary info
string current_type = "";
vector<symbol_info*> params_list;
vector<string> saved_param_details;


ofstream error_log;
int error_count = 0;
vector<string> current_arg_types; //store the passing arg

void yyerror(char *s)
{
	outlog<<"At line "<<lines<<" "<<s<<endl<<endl;
}

%}

%token IF ELSE FOR WHILE DO BREAK INT CHAR FLOAT DOUBLE VOID RETURN SWITCH CASE DEFAULT CONTINUE PRINTLN ADDOP MULOP INCOP DECOP RELOP ASSIGNOP LOGICOP NOT LPAREN RPAREN LCURL RCURL LTHIRD RTHIRD COMMA SEMICOLON CONST_INT CONST_FLOAT ID

%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE

%%

start : program
	{
		outlog<<"At line no: "<<lines<<" start : program "<<endl<<endl;
		outlog<<"Symbol Table"<<endl<<endl;
		
		// 4. Print your whole symbol table here
        st->print_all_scopes(outlog);
	}
	;

program : program unit
	{
		outlog<<"At line no: "<<lines<<" program : program unit "<<endl<<endl;
		outlog<<$1->get_name()+"\n"+$2->get_name()<<endl<<endl;
		$$ = new symbol_info($1->get_name()+"\n"+$2->get_name(),"program");
	}
	| unit
	{
		outlog<<"At line no: "<<lines<<" program : unit "<<endl<<endl;
		outlog<<$1->get_name()<<endl<<endl;
		$$ = new symbol_info($1->get_name(),"program");
	}
	;

unit : var_declaration
	 {
		outlog<<"At line no: "<<lines<<" unit : var_declaration "<<endl<<endl;
		outlog<<$1->get_name()<<endl<<endl;
		$$ = new symbol_info($1->get_name(),"unit");
	 }
     | func_definition
     {
		outlog<<"At line no: "<<lines<<" unit : func_definition "<<endl<<endl;
		outlog<<$1->get_name()<<endl<<endl;
		$$ = new symbol_info($1->get_name(),"unit");
	 }
     ;

func_definition : type_specifier ID LPAREN parameter_list RPAREN compound_statement
		{	
			outlog<<"At line no: "<<lines<<" func_definition : type_specifier ID LPAREN parameter_list RPAREN compound_statement "<<endl<<endl;
			outlog<<$1->get_name()<<" "<<$2->get_name()<<"("+$4->get_name()+")\n"<<$6->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name()+" "+$2->get_name()+"("+$4->get_name()+")\n"+$6->get_name(),"func_def");	
			
            symbol_info* func = new symbol_info($2->get_name(), "ID");
            func->set_symbol_category("FUNCTION");
            func->set_data_type($1->get_name()); // Set return type
            for(string p : saved_param_details) {
                func->add_parameter_type(p);
            }
            if (!st->insert(func)) {
                error_log << "At line no: " << lines << " Multiple declaration of function " << $2->get_name() << endl << endl;
                error_count++;
            }
            saved_param_details.clear(); // Clear for next functions
		}
		| type_specifier ID LPAREN RPAREN compound_statement
		{
			outlog<<"At line no: "<<lines<<" func_definition : type_specifier ID LPAREN RPAREN compound_statement "<<endl<<endl;
			outlog<<$1->get_name()<<" "<<$2->get_name()<<"()\n"<<$5->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name()+" "+$2->get_name()+"()\n"+$5->get_name(),"func_def");	
			
            symbol_info* func = new symbol_info($2->get_name(), "ID");
            func->set_symbol_category("FUNCTION");
            func->set_data_type($1->get_name()); 
            if (!st->insert(func)) {
                error_log << "At line no: " << lines << " Multiple declaration of function " << $2->get_name() << endl << endl;
                error_count++;
            }
		}
 		;

parameter_list : parameter_list COMMA type_specifier ID
		{
			outlog<<"At line no: "<<lines<<" parameter_list : parameter_list COMMA type_specifier ID "<<endl<<endl;
			outlog<<$1->get_name()<<","<<$3->get_name()<<" "<<$4->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name()+","+$3->get_name()+" "+$4->get_name(),"param_list");
			
            // same declaration in same scoope "fuction"
            bool duplicate = false;
            for(auto p : params_list) {
                if(p->get_name() == $4->get_name()) {
                    error_log << "At line no: " << lines << " Multiple declaration of variable " << $4->get_name() << " in parameter" << endl << endl;
                    error_count++;
                    duplicate = true;
                    break;
                }
            }
            if(!duplicate) {
                symbol_info* param = new symbol_info($4->get_name(), "ID");
                param->set_symbol_category("VAR");
                param->set_data_type(current_type);
                params_list.push_back(param);
                saved_param_details.push_back(current_type + " " + $4->get_name());
            }
		}
		| parameter_list COMMA type_specifier
		{
            
		}
 		| type_specifier ID
 		{
			outlog<<"At line no: "<<lines<<" parameter_list : type_specifier ID "<<endl<<endl;
			outlog<<$1->get_name()<<" "<<$2->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name()+" "+$2->get_name(),"param_list");
			
            // Check for duplicate parameter name 
            bool duplicate = false;
            for(auto p : params_list) {
                if(p->get_name() == $2->get_name()) {
                    error_log << "At line no: " << lines << " Multiple declaration of variable " << $2->get_name() << " in parameter" << endl << endl;
                    error_count++;
                    duplicate = true;
                    break;
                }
            }
            if(!duplicate) {
                symbol_info* param = new symbol_info($2->get_name(), "ID");
                param->set_symbol_category("VAR");
                param->set_data_type(current_type);
                params_list.push_back(param);
                saved_param_details.push_back(current_type + " " + $2->get_name());
            }
		}
		| type_specifier
		{
            
		}
 		;

compound_statement : LCURL {
                // MID-RULE ACTION: Enter scope and insert params
                st->enter_scope();
                for(auto p : params_list) {
                    st->insert(p);
                }
                params_list.clear();
            } statements RCURL
			{ 
 		 	    outlog<<"At line no: "<<lines<<" compound_statement : LCURL statements RCURL "<<endl<<endl;
				outlog<<"{\n"+$3->get_name()+"\n}"<<endl<<endl;
				$$ = new symbol_info("{\n"+$3->get_name()+"\n}","comp_stmnt");
				
                // Print and Exit Scope
                st->print_all_scopes(outlog);
                st->exit_scope();
 		    }
 		    | LCURL {
                // MID-RULE ACTION: Enter scope and insert params
                st->enter_scope();
                for(auto p : params_list) {
                    st->insert(p);
                }
                params_list.clear();
            } RCURL
 		    { 
 		 	    outlog<<"At line no: "<<lines<<" compound_statement : LCURL RCURL "<<endl<<endl;
				outlog<<"{\n}"<<endl<<endl;
				$$ = new symbol_info("{\n}","comp_stmnt");
				
                // Print and Exit Scope
                st->print_all_scopes(outlog);
                st->exit_scope();
 		    }
 		    ;
 		    
var_declaration : type_specifier declaration_list SEMICOLON
		 {
			outlog<<"At line no: "<<lines<<" var_declaration : type_specifier declaration_list SEMICOLON "<<endl<<endl;
			outlog<<$1->get_name()<<" "<<$2->get_name()<<";"<<endl<<endl;
			$$ = new symbol_info($1->get_name()+" "+$2->get_name()+";","var_dec");
		 }
 		 ;

type_specifier : INT
		{
			outlog<<"At line no: "<<lines<<" type_specifier : INT "<<endl<<endl;
			outlog<<"int"<<endl<<endl;
			$$ = new symbol_info("int","type");
            current_type = "int"; 
	    }
 		| FLOAT
 		{
			outlog<<"At line no: "<<lines<<" type_specifier : FLOAT "<<endl<<endl;
			outlog<<"float"<<endl<<endl;
			$$ = new symbol_info("float","type");
            current_type = "float"; 
	    }
 		| VOID
 		{
			outlog<<"At line no: "<<lines<<" type_specifier : VOID "<<endl<<endl;
			outlog<<"void"<<endl<<endl;
			$$ = new symbol_info("void","type");
            current_type = "void"; 
	    }
 		;

declaration_list : declaration_list COMMA ID
		  {
		 	outlog<<"At line no: "<<lines<<" declaration_list : declaration_list COMMA ID "<<endl<<endl;
		 	outlog<<$1->get_name()+","<<$3->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name()+","+$3->get_name(), "decl_list"); 

            if (current_type == "void") {
                error_log << "At line no: " << lines << " variable type can not be void " << endl << endl;
                error_count++;
            } else {
                symbol_info* s = new symbol_info($3->get_name(), "ID");
                s->set_symbol_category("VAR");
                s->set_data_type(current_type);
                if (!st->insert(s)) {
                    error_log << "At line no: " << lines << " Multiple declaration of variable " << $3->get_name() << endl << endl;
                    error_count++;
                }
            }
		  }
		  | declaration_list COMMA ID LTHIRD CONST_INT RTHIRD 
		  {
		 	outlog<<"At line no: "<<lines<<" declaration_list : declaration_list COMMA ID LTHIRD CONST_INT RTHIRD "<<endl<<endl;
		 	outlog<<$1->get_name()+","<<$3->get_name()<<"["<<$5->get_name()<<"]"<<endl<<endl;
            $$ = new symbol_info($1->get_name()+","+$3->get_name()+"["+$5->get_name()+"]", "decl_list"); 

            if (current_type == "void") {
                error_log << "At line no: " << lines << " variable type can not be void " << endl << endl;
                error_count++;
            } else {
                symbol_info* s = new symbol_info($3->get_name(), "ID");
                s->set_symbol_category("ARRAY");
                s->set_data_type(current_type);
                s->set_array_size(stoi($5->get_name()));
                if (!st->insert(s)) {
                    error_log << "At line no: " << lines << " Multiple declaration of variable " << $3->get_name() << endl << endl;
                    error_count++;
                }
            }
		  }
		  |ID
		  {
		 	outlog<<"At line no: "<<lines<<" declaration_list : ID "<<endl<<endl;
			outlog<<$1->get_name()<<endl<<endl;
            $$ = new symbol_info($1->get_name(), "decl_list"); 

            if (current_type == "void") {
                error_log << "At line no: " << lines << " variable type can not be void " << endl << endl;
                error_count++;
            } else {
                symbol_info* s = new symbol_info($1->get_name(), "ID");
                s->set_symbol_category("VAR");
                s->set_data_type(current_type);
                if (!st->insert(s)) {
                    error_log << "At line no: " << lines << " Multiple declaration of variable " << $1->get_name() << endl << endl;
                    error_count++;
                }
            }
		  }
		  | ID LTHIRD CONST_INT RTHIRD 
		  {
		 	outlog<<"At line no: "<<lines<<" declaration_list : ID LTHIRD CONST_INT RTHIRD "<<endl<<endl;
			outlog<<$1->get_name()<<"["<<$3->get_name()<<"]"<<endl<<endl;
            $$ = new symbol_info($1->get_name()+"["+$3->get_name()+"]", "decl_list"); 

            if (current_type == "void") {
                error_log << "At line no: " << lines << " variable type can not be void " << endl << endl;
                error_count++;
            } else {
                symbol_info* s = new symbol_info($1->get_name(), "ID");
                s->set_symbol_category("ARRAY");
                s->set_data_type(current_type);
                s->set_array_size(stoi($3->get_name()));
                if (!st->insert(s)) {
                    error_log << "At line no: " << lines << " Multiple declaration of variable " << $1->get_name() << endl << endl;
                    error_count++;
                }
            }
		  }
		  ;
 		  
statements : statement
	   {
	    	outlog<<"At line no: "<<lines<<" statements : statement "<<endl<<endl;
			outlog<<$1->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name(),"stmnts");
	   }
	   | statements statement
	   {
	    	outlog<<"At line no: "<<lines<<" statements : statements statement "<<endl<<endl;
			outlog<<$1->get_name()<<"\n"<<$2->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name()+"\n"+$2->get_name(),"stmnts");
	   }
	   ;
	   
statement : var_declaration
	  {
	    	outlog<<"At line no: "<<lines<<" statement : var_declaration "<<endl<<endl;
			outlog<<$1->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name(),"stmnt");
	  }
	  | func_definition
	  {
	  		outlog<<"At line no: "<<lines<<" statement : func_definition "<<endl<<endl;
            outlog<<$1->get_name()<<endl<<endl;
            $$ = new symbol_info($1->get_name(),"stmnt");
	  }
	  | expression_statement
	  {
	    	outlog<<"At line no: "<<lines<<" statement : expression_statement "<<endl<<endl;
			outlog<<$1->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name(),"stmnt");
	  }
	  | compound_statement
	  {
	    	outlog<<"At line no: "<<lines<<" statement : compound_statement "<<endl<<endl;
			outlog<<$1->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name(),"stmnt");
	  }
	  | FOR LPAREN expression_statement expression_statement expression RPAREN statement
	  {
	    	outlog<<"At line no: "<<lines<<" statement : FOR LPAREN expression_statement expression_statement expression RPAREN statement "<<endl<<endl;
			outlog<<"for("<<$3->get_name()<<$4->get_name()<<$5->get_name()<<")\n"<<$7->get_name()<<endl<<endl;
			$$ = new symbol_info("for("+$3->get_name()+$4->get_name()+$5->get_name()+")\n"+$7->get_name(),"stmnt");
	  }
	  | IF LPAREN expression RPAREN statement %prec LOWER_THAN_ELSE
	  {
	    	outlog<<"At line no: "<<lines<<" statement : IF LPAREN expression RPAREN statement "<<endl<<endl;
			outlog<<"if("<<$3->get_name()<<")\n"<<$5->get_name()<<endl<<endl;
			$$ = new symbol_info("if("+$3->get_name()+")\n"+$5->get_name(),"stmnt");
	  }
	  | IF LPAREN expression RPAREN statement ELSE statement
	  {
	    	outlog<<"At line no: "<<lines<<" statement : IF LPAREN expression RPAREN statement ELSE statement "<<endl<<endl;
			outlog<<"if("<<$3->get_name()<<")\n"<<$5->get_name()<<"\nelse\n"<<$7->get_name()<<endl<<endl;
			$$ = new symbol_info("if("+$3->get_name()+")\n"+$5->get_name()+"\nelse\n"+$7->get_name(),"stmnt");
	  }
	  | WHILE LPAREN expression RPAREN statement
	  {
	    	outlog<<"At line no: "<<lines<<" statement : WHILE LPAREN expression RPAREN statement "<<endl<<endl;
			outlog<<"while("<<$3->get_name()<<")\n"<<$5->get_name()<<endl<<endl;
			$$ = new symbol_info("while("+$3->get_name()+")\n"+$5->get_name(),"stmnt");
	  }
	  | PRINTLN LPAREN ID RPAREN SEMICOLON
	  {
	    	outlog<<"At line no: "<<lines<<" statement : PRINTLN LPAREN ID RPAREN SEMICOLON "<<endl<<endl;
			outlog<<"printf("<<$3->get_name()<<");"<<endl<<endl; 
			$$ = new symbol_info("printf("+$3->get_name()+");","stmnt");
        symbol_info* sym = st->lookup($3);
        if (sym == NULL) {
            error_log << "At line no: " << lines << " Undeclared variable " << $3->get_name() << endl << endl;
            error_count++;
		}
	  }
	  | RETURN expression SEMICOLON
	  {
	    	outlog<<"At line no: "<<lines<<" statement : RETURN expression SEMICOLON "<<endl<<endl;
			outlog<<"return "<<$2->get_name()<<";"<<endl<<endl;
			$$ = new symbol_info("return "+$2->get_name()+";","stmnt");
	  }
	  ;
	  
expression_statement : SEMICOLON
			{
				outlog<<"At line no: "<<lines<<" expression_statement : SEMICOLON "<<endl<<endl;
				outlog<<";"<<endl<<endl;
				$$ = new symbol_info(";","expr_stmt");
	        }			
			| expression SEMICOLON 
			{
				outlog<<"At line no: "<<lines<<" expression_statement : expression SEMICOLON "<<endl<<endl;
				outlog<<$1->get_name()<<";"<<endl<<endl;
				$$ = new symbol_info($1->get_name()+";","expr_stmt");
	        }
			;
	  
variable : ID 
      {
	    outlog<<"At line no: "<<lines<<" variable : ID "<<endl<<endl;
		outlog<<$1->get_name()<<endl<<endl;
		$$ = new symbol_info($1->get_name(),"varbl");
        
        symbol_info* sym = st->lookup($1);
        
        if (sym == NULL) {
            error_log << "At line no: " << lines << " Undeclared variable " << $1->get_name() << endl << endl;
            error_count++;
            $$->set_data_type("int"); // fallback 
        } 
        else {
            if (sym->get_symbol_category() == "ARRAY") {
                
                error_log << "At line no: " << lines << " variable is of array type : " << $1->get_name() << endl << endl;
                error_count++;
            }
            $$->set_data_type(sym->get_data_type()); 
        }
	  }
	  | ID LTHIRD expression RTHIRD 
	  {
	    outlog<<"At line no: "<<lines<<" variable : ID LTHIRD expression RTHIRD "<<endl<<endl;
		outlog<<$1->get_name()<<"["<<$3->get_name()<<"]"<<endl<<endl;
		$$ = new symbol_info($1->get_name()+"["+$3->get_name()+"]","varbl");
        
        symbol_info* sym = st->lookup($1);
        
        if (sym == NULL) {
            error_log << "At line no: " << lines << " Undeclared variable " << $1->get_name() << endl << endl;
            error_count++;
            $$->set_data_type("int"); // fallback 
        } 
        else {
            if (sym->get_symbol_category() != "ARRAY") {
                // FIXED STRING
                error_log << "At line no: " << lines << " variable is not of array type : " << $1->get_name() << endl << endl;
                error_count++;
            }
            $$->set_data_type(sym->get_data_type()); 
        }
        
        if ($3->get_data_type() != "int") {
            
            error_log << "At line no: " << lines << " array index is not of integer type : " << $1->get_name() << endl << endl;
            error_count++;
        }
	  }
	  ;
expression : logic_expression	
	   {
	    	outlog<<"At line no: "<<lines<<" expression : logic_expression "<<endl<<endl;
			outlog<<$1->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name(),"expr");
			
			// Pass the data type up!
			$$->set_data_type($1->get_data_type());
	   }
	   | variable ASSIGNOP logic_expression 	
	   {
	    	outlog<<"At line no: "<<lines<<" expression : variable ASSIGNOP logic_expression "<<endl<<endl;
			outlog<<$1->get_name()<<"="<<$3->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name()+"="+$3->get_name(),"expr");
            
            string left_type = $1->get_data_type();
            string right_type = $3->get_data_type();
            
            
            if (left_type == "void" || right_type == "void") {
                error_log << "At line no: " << lines << " operation on void type " << endl << endl;
                error_count++;
            } 
            //  Warning if float is assigned to int
            else if (left_type == "int" && right_type == "float") {
                error_log << "At line no: " << lines << " Warning: Assignment of float value into variable of integer type " << endl << endl;
                error_count++; //count as error
            }
            
            $$->set_data_type(left_type); 
	   }
	   ;
logic_expression : rel_expression
	   {
	    	outlog<<"At line no: "<<lines<<" logic_expression : rel_expression "<<endl<<endl;
			outlog<<$1->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name(),"lgc_expr");
            
			$$->set_data_type($1->get_data_type()); // Bubble up
	   }	
	   | rel_expression LOGICOP rel_expression 
	   {
	    	outlog<<"At line no: "<<lines<<" logic_expression : rel_expression LOGICOP rel_expression "<<endl<<endl;
			outlog<<$1->get_name()<<$2->get_name()<<$3->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name()+$2->get_name()+$3->get_name(),"lgc_expr");
            
            //  Result of LOGICOP is ALWAYS an integer &&,||
            $$->set_data_type("int");
	   }	
	   ;
			
rel_expression	: simple_expression
	   {
	    	outlog<<"At line no: "<<lines<<" rel_expression : simple_expression "<<endl<<endl;
			outlog<<$1->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name(),"rel_expr");
            
			$$->set_data_type($1->get_data_type()); // Bubble up
	   }
	   | simple_expression RELOP simple_expression
	   {
	    	outlog<<"At line no: "<<lines<<" rel_expression : simple_expression RELOP simple_expression "<<endl<<endl;
			outlog<<$1->get_name()<<$2->get_name()<<$3->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name()+$2->get_name()+$3->get_name(),"rel_expr");
            
            //  Result of RELOP is ALWAYS an integer  <,>,>=,<=
            $$->set_data_type("int");
	   }
	   ;
				
simple_expression : term
          {
	    	outlog<<"At line no: "<<lines<<" simple_expression : term "<<endl<<endl;
			outlog<<$1->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name(),"simp_expr");
			$$->set_data_type($1->get_data_type()); // Bubble up
	      }
		  | simple_expression ADDOP term 
		  {
	    	outlog<<"At line no: "<<lines<<" simple_expression : simple_expression ADDOP term "<<endl<<endl;
			outlog<<$1->get_name()<<$2->get_name()<<$3->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name()+$2->get_name()+$3->get_name(),"simp_expr");
            
            string type1 = $1->get_data_type();
            string type2 = $3->get_data_type();
            
            //  Cannot do math with void functions
            if (type1 == "void" || type2 == "void") {
                error_log << "At line no: " << lines << " operation on void type " << endl << endl;
                error_count++;
                $$->set_data_type("int"); // Fallback to int to prevent cascading errors
            } 
            else {
                // Result is float if any operand is float, else int
                if (type1 == "float" || type2 == "float") $$->set_data_type("float");
                else $$->set_data_type("int");
            }
	      }
		  ;
					
term :	unary_expression
     {
	    outlog<<"At line no: "<<lines<<" term : unary_expression "<<endl<<endl;
		outlog<<$1->get_name()<<endl<<endl;
		$$ = new symbol_info($1->get_name(),"term");
		$$->set_data_type($1->get_data_type()); // Bubble up
	 }
     |  term MULOP unary_expression
     {
	    outlog<<"At line no: "<<lines<<" term : term MULOP unary_expression "<<endl<<endl;
		outlog<<$1->get_name()<<$2->get_name()<<$3->get_name()<<endl<<endl;
		$$ = new symbol_info($1->get_name()+$2->get_name()+$3->get_name(),"term");
        
        string op = $2->get_name();
        string type1 = $1->get_data_type();
        string type2 = $3->get_data_type();

       
        if (type1 == "void" || type2 == "void") {
            error_log << "At line no: " << lines << " operation on void type " << endl << endl;
            error_count++;
            $$->set_data_type("int"); // Fallback to int to prevent cascading errors
        }
        else if (op == "%") {
            // Task 4 Check: Modulus by 0
            if ($3->get_name() == "0" || $3->get_name() == "0.0") {
                error_log << "At line no: " << lines << " Modulus by 0 " << endl << endl;
                error_count++;
            }
           
            else if (type1 != "int" || type2 != "int") {
                error_log << "At line no: " << lines << " Modulus operator on non integer type " << endl << endl;
                error_count++;
            }
            $$->set_data_type("int"); // Modulus always results in an int
        }
        else if (op == "/") {
            
            if ($3->get_name() == "0" || $3->get_name() == "0.0") {
                error_log << "At line no: " << lines << " Division by 0 " << endl << endl;
                error_count++;
            }
            
            // Result is float if any operand is float, else int
            if (type1 == "float" || type2 == "float") $$->set_data_type("float");
            else $$->set_data_type("int");
        }
        else { // Operator is '*'
            // Result is float if any operand is float, else int
            if (type1 == "float" || type2 == "float") $$->set_data_type("float");
            else $$->set_data_type("int");
        }
	 }
     ;

unary_expression : ADDOP unary_expression 
		 {
	    	outlog<<"At line no: "<<lines<<" unary_expression : ADDOP unary_expression "<<endl<<endl;
			outlog<<$1->get_name()<<$2->get_name()<<endl<<endl;
			$$ = new symbol_info($1->get_name()+$2->get_name(),"un_expr");
			
			
			$$->set_data_type($2->get_data_type());
	     }
		 | NOT unary_expression 
		 {
	    	outlog<<"At line no: "<<lines<<" unary_expression : NOT unary_expression "<<endl<<endl;
			outlog<<"!"<<$2->get_name()<<endl<<endl;
			$$ = new symbol_info("!"+$2->get_name(),"un_expr");
			
			// NOT (!) operations return a boolean/integer
			$$->set_data_type("int");
	     }
		 | factor 
		 {
	    	outlog<<"At line no: "<<lines<<" unary_expression : factor "<<endl<<endl;
			outlog<<$1->get_name()<<endl<<endl;
		    $$ = new symbol_info($1->get_name(),"un_expr");
			
			
			$$->set_data_type($1->get_data_type());
	     }
		 ;
factor	: variable
    {
	    outlog<<"At line no: "<<lines<<" factor : variable "<<endl<<endl;
		outlog<<$1->get_name()<<endl<<endl;
		$$ = new symbol_info($1->get_name(),"fctr");
		$$->set_data_type($1->get_data_type());
	}
	| ID LPAREN argument_list RPAREN
	{
	    outlog<<"At line no: "<<lines<<" factor : ID LPAREN argument_list RPAREN "<<endl<<endl;
		outlog<<$1->get_name()<<"("<<$3->get_name()<<")"<<endl<<endl;
		$$ = new symbol_info($1->get_name()+"("+$3->get_name()+")","fctr");
        
        //  CHECK ID IN ST
        symbol_info* func_symbol = st->lookup($1);
        
        if (func_symbol == NULL) {
            
            error_log << "At line no: " << lines << " Undeclared function: " << $1->get_name() << endl << endl;
            error_count++;
        } 
        else if (func_symbol->get_symbol_category() != "FUNCTION") {
            //fuction call as fuction
            error_log << "At line no: " << lines << " " << $1->get_name() << " is not a function." << endl << endl;
            error_count++;
        } 
        else {
            
            $$->set_data_type(func_symbol->get_data_type()); 
            
            vector<string> param_list = func_symbol->get_parameter_list();
            
            //  Compare argument size with parameter size
            if (current_arg_types.size() != param_list.size()) {
                error_log << "At line no: " << lines << " Inconsistencies in number of arguments in function call: " << $1->get_name() << endl << endl;
                error_count++;
            } 
            else {
                //  Check if the types match exactly
                for (size_t i = 0; i < param_list.size(); i++) {
                    
                    string p_type = param_list[i].substr(0, param_list[i].find(" ")); 
                    
                    if (current_arg_types[i] != p_type) {
                        error_log << "At line no: " << lines << " argument " << i+1 << " type mismatch in function call: " << $1->get_name() << endl << endl;
                        error_count++;
                    }
                }
            }
        }
        
        
        current_arg_types.clear();
	}
	| LPAREN expression RPAREN
	{
	   	outlog<<"At line no: "<<lines<<" factor : LPAREN expression RPAREN "<<endl<<endl;
		outlog<<"("<<$2->get_name()<<")"<<endl<<endl;
		$$ = new symbol_info("("+$2->get_name()+")","fctr");
		$$->set_data_type($2->get_data_type());
	}
	| CONST_INT 
	{
	    outlog<<"At line no: "<<lines<<" factor : CONST_INT "<<endl<<endl;
		outlog<<$1->get_name()<<endl<<endl;
		$$ = new symbol_info($1->get_name(),"fctr");
	$$->set_data_type("int");
	}
	| CONST_FLOAT
	{
	    outlog<<"At line no: "<<lines<<" factor : CONST_FLOAT "<<endl<<endl;
		outlog<<$1->get_name()<<endl<<endl;
		$$ = new symbol_info($1->get_name(),"fctr");
	$$->set_data_type("float");
	}
	| variable INCOP 
	{
	    outlog<<"At line no: "<<lines<<" factor : variable INCOP "<<endl<<endl;
		outlog<<$1->get_name()<<"++"<<endl<<endl;
		$$ = new symbol_info($1->get_name()+"++","fctr");
		$$->set_data_type($1->get_data_type());
	}
	| variable DECOP
	{
	    outlog<<"At line no: "<<lines<<" factor : variable DECOP "<<endl<<endl;
		outlog<<$1->get_name()<<"--"<<endl<<endl;
		$$ = new symbol_info($1->get_name()+"--","fctr");
		$$->set_data_type($1->get_data_type());
	}
	;
	
argument_list : arguments
			  {
					outlog<<"At line no: "<<lines<<" argument_list : arguments "<<endl<<endl;
					outlog<<$1->get_name()<<endl<<endl;
					$$ = new symbol_info($1->get_name(),"arg_list");
			  }
			  |
			  {
					outlog<<"At line no: "<<lines<<" argument_list :  "<<endl<<endl;
					outlog<<""<<endl<<endl;
					$$ = new symbol_info("","arg_list");
			  }
			  ;
	
arguments : arguments COMMA logic_expression
		  {
				outlog<<"At line no: "<<lines<<" arguments : arguments COMMA logic_expression "<<endl<<endl;
				outlog<<$1->get_name()<<","<<$3->get_name()<<endl<<endl;
				$$ = new symbol_info($1->get_name()+","+$3->get_name(),"arg");
                
            
                current_arg_types.push_back($3->get_data_type()); //push the type
		  }
	      | logic_expression
	      {
				outlog<<"At line no: "<<lines<<" arguments : logic_expression "<<endl<<endl;
				outlog<<$1->get_name()<<endl<<endl;
				$$ = new symbol_info($1->get_name(),"arg");
                
                
                current_arg_types.push_back($1->get_data_type()); //push the type
		  }
	      ;
%%

int main(int argc, char *argv[])
{
	if(argc != 2) 
	{
		cout<<"input2.c"<<endl;
		return 0;
	}
	yyin = fopen(argv[1], "r");
	
	outlog.open("21301044_log.txt", ios::trunc); 
    error_log.open("21301044_error.txt", ios::trunc); 
	
	if(yyin == NULL)
	{
		cout<<"Couldn't open file"<<endl;
		return 0;
	}

	st = new symbol_table(30); 

	yyparse();
	
	outlog<<endl<<"Total lines: "<<lines<<endl;
    outlog<<endl<<"Total errors: "<<error_count<<endl; 
    
    error_log<<endl<<"Total errors: "<<error_count<<endl; 
	
    outlog.close();
    error_log.close(); // ADDED
	fclose(yyin);
	
	return 0;
}